<?php

// Make sure the file is not directly accessible.
if ( ! defined( 'ABSPATH' ) ) {
	die( 'We\'re sorry, but you can not directly access this file.' );
}

?>

<div id="health-check-diff-modal">
	<div id="health-check-diff-modal-content">
		<a id="health-check-diff-modal-close-ref" href="#health-check-diff-modal-close"><span class="dashicons dashicons-no"></span></a>
		<span class="spinner"></span>
		<h3></h3>
		<div id="health-check-diff-modal-diff">
		</div>
	</div>
</div>
